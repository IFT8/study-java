package com.comodin.fleet.picture.utils.opencv;

import org.opencv.core.*;
import org.opencv.imgcodecs.Imgcodecs;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import java.io.File;
import java.net.URLDecoder;
import java.util.ArrayList;
import java.util.List;


public class DFTUtilsTest {

    private String sourcePictureFilePathStr;
    private File outRootDir;
    Mat srcImageMat;

    @BeforeClass
    public void setUp() throws Exception {
        System.loadLibrary(Core.NATIVE_LIBRARY_NAME);
        sourcePictureFilePathStr = URLDecoder.decode(ImageFiltersUtilsTest.class.getResource("/dev_image_template/companiesCode_signaturePicture.jpg").getFile(), "UTF-8").substring(1);
        outRootDir = new File(sourcePictureFilePathStr).getParentFile();

        srcImageMat = Imgcodecs.imread(sourcePictureFilePathStr);
    }

    @Test
    public void testTransformImageWithText() throws Exception {
        DFTUtils dftUtils = DFTUtils.getInstance();

        Point point = new Point(50, 100);
        Scalar scalar = new Scalar(0, 0, 0, 0);
        double fontSize = 0.7d;
        String waterMarkText = "comodin";
        Mat sourcePictureFilePathMat = Imgcodecs.imread(sourcePictureFilePathStr);

        List<Mat> mv = new ArrayList<>();
        Core.split(sourcePictureFilePathMat,mv);

        List<Mat> anMv = new ArrayList<>();//存放转变后的

        dftUtils.transformImageWithText(mv.get(1), waterMarkText, point,fontSize,scalar);

        Mat transformImageWithTextMat = dftUtils.antitransformImage();
        Imgcodecs.imwrite("D:\\changeResult.png", transformImageWithTextMat);
        Mat mat = dftUtils.transformImage(transformImageWithTextMat);
        Imgcodecs.imwrite("D:\\changeFFT.png", mat);

        anMv.add(mv.get(0));
        anMv.add(transformImageWithTextMat);
        anMv.add(mv.get(2));

        Mat changeBack = new Mat();
        Core.merge(anMv,changeBack);
        String changeBackPath = "D:\\changeBack.png";
        Imgcodecs.imwrite(changeBackPath, changeBack);

        Mat changeCheck = Imgcodecs.imread(changeBackPath);
        List<Mat> changeCheckMv = new ArrayList<>();
        Core.split(changeCheck,changeCheckMv);


        for (int i = 0; i<changeCheckMv.size() ; i++) {

            Imgcodecs.imwrite("D:\\changeBack"+i+".png", dftUtils.transformImage(changeCheckMv.get(i)));

        }

    }


    @Test
    public void testName001() throws Exception {
        Mat mat = Mat.eye(3, 3, CvType.CV_8UC1);
        System.out.println(mat.dump());
    }

    @Test
    public void testAddWatermark(){

        DFTUtils.addWatermark(sourcePictureFilePathStr,"D:\\watermark.jpg","hcj");

    }
}